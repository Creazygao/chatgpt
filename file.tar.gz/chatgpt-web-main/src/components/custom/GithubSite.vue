<template>
  <div class="text-neutral-400">
    <span>KeepMoving.tech</span>
  </div>
</template>
